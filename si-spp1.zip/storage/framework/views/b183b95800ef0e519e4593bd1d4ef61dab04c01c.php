<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Manajemen Siswa</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Siswa</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Filter</h4>
                        <div class="card-header-action">
                            <a data-collapse="#mycard-collapse" class="btn btn-icon btn-info" href="#"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                    <div class="collapse" id="mycard-collapse" style="">
                        <div class="card-body">
                            <form action="" action="GET">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="jk">Jenis Kelamin</label>
                                        <select name="jk" id="jk" class="form-control <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">-Pilih Semua-</option>
                                            <option value="male" <?php echo e(('male' === request()->jk) ? 'selected' : ''); ?>>Laki-laki</option>
                                            <option value="female" <?php echo e(('female' === request()->jk) ? 'selected' : ''); ?>>Perempuan</option>
                                        </select>
                                        <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="status">Status</label>
                                        <select name="status" id="status" class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">-Pilih Semua-</option>
                                            <option value="Aktif" <?php echo e(('Aktif' === request()->status) ? 'selected' : ''); ?>>Aktif</option>
                                            <option value="Lulus" <?php echo e(('Lulus' === request()->status) ? 'selected' : ''); ?>>Lulus</option>
                                            <option value="Pindah" <?php echo e(('Pindah' === request()->status) ? 'selected' : ''); ?>>Pindah</option>
                                            <option value="Dikeluarkan" <?php echo e(('Dikeluarkan' === request()->status) ? 'selected' : ''); ?>>Dikeluarkan</option>
                                        </select>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="kelas_id">Kelas</label>
                                        <select name="kelas_id" id="kelas_id" class="form-control <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">-Pilih Semua-</option>
                                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                    <?php if($item->id == request()->kelas_id): ?>
                                                        selected
                                                    <?php endif; ?>    
                                                >
                                                
                                                <?php echo e($item->nama_kelas); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="text-right">
                                        <button class="btn btn-primary ">Filter</button>
                                    </div>
                                </div>
                            </div>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <h4>Data Siswa</h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-primary btn-icon"
                                data-toggle="tooltip" data-placement="top" title=""
                                data-original-title="Tambah Data">
                                <i class="fas fa-plus-circle px-2    "></i>
                            </a>
                            <a href="#" class="btn btn-secondary btn-icon ml-2" onclick="handleImport()"
                                title="Import File" data-toggle="tooltip" data-placement="top"
                                data-original-title="Import Data Siswa">
                                <i class="fas fa-file-import px-2   "></i>
                            </a>
                            <a href="<?php echo e(route('siswa.pdf')); ?>" target="blank"
                                class="btn btn-secondary btn-icon ml-2" title="Cetak PDF" data-toggle="tooltip"
                                data-placement="top" data-original-title="Cetak PDF">
                                <i class="fas fa-file-pdf  px-2  "></i>
                            </a>

                            <a href="<?php echo e(route('siswa.excel')); ?>" target="_blank"
                                class="btn btn-secondary btn-icon ml-2" title="Export Excel" data-toggle="tooltip"
                                data-placement="top" data-original-title="Export Excel">
                                <i class="fas fa-file-excel  px-2  "></i>
                            </a>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        
                        <form action="<?php echo e(route('siswa.index')); ?>" method="GET">
                            
                            <div class="input-group input-group mb-3 float-right" style="width: 300px;">
                                <input type="text" name="keyword" class="form-control float-right"
                                placeholder="Search" value="<?php echo e(request()->query('keyword')); ?>">
    
                                
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-light"><i class="fas fa-search"></i></button>
                                </div>
                                <div class="input-group-append">
                                    <a href="<?php echo e(route('siswa.index')); ?>" title="Refresh" class="btn btn-light"><i class="fas fa-circle-notch mt-2    "></i></a>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table table-head-fixed text-nowrap table-bordered">
                                <thead>
                                    <tr class="text-center">
                                        <th>#</th>
                                        <th>No</th>
                                        <th>Foto</th>
                                        <th>Nis Nama</th>
                                        <th>Tgl.Lahir</th>
                                        <th>JK</th>
                                        <th>Kelas</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td style="width: 20px">
                                                <div class="btn-group">
                                                    <button type="button" class="btn" data-toggle="dropdown">
                                                        <i class="fas fa-ellipsis-v    "></i>
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('siswa.edit', $row->id)); ?>">
                                                                <i class="fas fa-edit    "></i>
                                                                Edit
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="#"
                                                                onclick="handleDelete (<?php echo e($row->id); ?>)">
                                                                <i class="fas fa-trash    "></i>
                                                                Delete
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </td>
                                            <td style="width: 50px"><?php echo e($loop->iteration + $siswa->firstItem() - 1); ?></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(asset('/img/siswa').'/'.$row->foto); ?>"
                                                    data-fancybox data-caption="<?php echo e($row->nama_lengkap); ?>">
                                                    <img width="64px" height="64px" class="my-2 rounded-circle shadow"
                                                        src="<?php echo e(asset('/img/siswa').'/'. $row->foto); ?>"
                                                        alt="">
                                                </a>    
                                            </td>
                                            <td>
                                                
                                                <a href="<?php echo e(route('siswa.show', $row->id )); ?>" class="text-dark">
                                                    <?php echo e($row->nis); ?> <br>
                                                    <?php echo e($row->nama_lengkap); ?>

                                                </a>
                                            </td>
                                            <td class="text-center"><?php echo e(date_format(date_create($row->tanggal_lahir),"d-m-Y")); ?></td>
                                            <td class="text-center"><?php echo e($row->jk); ?></td>
                                            <td><?php echo e((!empty($row->kelas->nama_kelas)) ? $row->kelas->nama_kelas : ''); ?></td>
                                            <td>
                                                <?php echo e($row->status); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">Data Tidak Ada</td>
                                        </tr>
                                    <?php endif; ?>
    
                                </tbody>
                            </table>
                            <?php echo e($siswa->appends([
                                'keyword' => request()->query('keyword'), 
                                'kelas_id' => request()->query('kelas_id'),
                                'jk' => request()->query('jk'),
                                'status' => request()->query('status'),
                            ])->links()); ?>

                        </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <span class="text-sm float-right">Total Entries : <?php echo e($siswa->total()); ?></span>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</section>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Hapus Data Siswa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mt-3">Apakah kamu yakin menghapus Data Siswa ?</p>
            </div>
            <div class="modal-footer">
                <form action="" method="POST" id="deleteForm">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak, Kembali</button>
                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal Import File-->
<div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Import Data Produk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('siswa.import')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="import_siswa">Import File</label>
                        <input type="file" class="form-control-file" name="import_siswa" id="import_siswa"
                            placeholder="" aria-describedby="fileHelpId" required>
                        <?php $__errorArgs = ['import_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small id="fileHelpId" class="form-text text-muted">Tipe file : xls, xlsx</small>
                        <small id="fileHelpId" class="form-text text-muted">Pastikan file upload sesuai format. <br> <a
                                href="<?php echo e(url('template/contoh_format_import_siswa.xlsx')); ?>">Download
                                contoh format file xlsx <i class="fas fa-download ml-1   "></i></a></small>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm')
        form.action = `./siswa/${id}`
        console.log(form)
        $('#deleteModal').modal('show')
    }

    function handleImport(e) {
        // e.preventDefault()
        $('#importModal').modal('show')
    }

</script>

<?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php $__errorArgs = ['import_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <script>
        $(document).ready(function () {
            // toastr["info"]('<?php echo e(session()->get('error')); ?>')
            iziToast.error({
                title: '',
                message: 'Import Data Siswa Gagal!',
                position: 'bottomCenter'
            });
        });
    </script>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<?php if(session()->has('error')): ?>
    <script>
        $(document).ready(function () {
            // toastr["info"]('<?php echo e(session()->get('error')); ?>')
            iziToast.info({
                title: '',
                message: '<?php echo e(session()->get('error')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samikun\Videos\fortesting\lara7-spp-master\si-spp\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>