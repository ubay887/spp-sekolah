<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Manajemen Kenaikan Kelas</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Kenaikan Kelas</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <h4>Kelas</h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(route('kelas.create')); ?>" class="btn btn-primary btn-icon"
                                data-toggle="tooltip" data-placement="top" title=""
                                data-original-title="Tambah Data">
                                <i class="fas fa-plus-circle px-2    "></i>
                            </a>
                            
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <form action="<?php echo e(route('kenaikanKelas.index')); ?>" method="get">
                                    <div class="form-group">
                                        <label for="kelas_id">Pilih Kelas</label>
                                        <select v-model="kelas_id" name="kelas_id" id="kelas_id" class="form-control <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">-Pilih Kelas-</option>
                                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                    <?php if($item->id == request()->kelas_id): ?>
                                                        selected
                                                    <?php endif; ?>    
                                                >
                                                
                                                <?php echo e($item->nama_kelas); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </form>                                
                            </div>
                        </div>
                        <!-- /.row -->   
                        <?php if($siswa): ?>
                        <form action="<?php echo e(route('kenaikanKelas.proses')); ?>" action="get">
                        <div class="row">
                            <div class="col-md-9">
                                
                                        
                                <div class="custom-control custom-checkbox py-3">
                                    <input type="checkbox" 
                                    name="pilih_semua" 
                                    value="semua" 
                                    class="custom-control-input" 
                                    id="one"
                                    >
                                    <label class="custom-control-label" for="one">Pilih Semua</label>
                                </div>
                                <?php $__errorArgs = ['siswa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mb-4">Pilih Salah Satu Siswa/i</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="form-group">
                                    
                                    <div class="row gutters-sm">
                                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-6 col-sm-4 col-md-2" >
                                                <label class="imagecheck mb-4">
                                                <input name="siswa_id[]" type="checkbox" value="<?php echo e($row->id); ?>" class="imagecheck-input"
                                                <?php echo e((is_array(old('siswa_id')) && in_array($row->id, old('siswa_id'))) ? 'checked' : ''); ?>

                                                >
                                                <figure class="imagecheck-figure">
                                                    <img height="120" width="120px" src="<?php echo e(asset('/img/siswa/').'/'.$row->foto); ?>" alt="" class="imagecheck-image">
                                                </figure>
                                                <span class="small">
                                                    <strong><?php echo e($row->nama_lengkap); ?></strong><br>
                                                    <?php echo e($row->nis); ?> <br>
                                                    <?php echo e($row->kelas->nama_kelas); ?>

                                                </span>
                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                

                            </div>
                            <div class="col-md-3">
                                <div class="pembayaranDetail">
                                    <div class="form-group ">
                                        <label for="kelas_id">Pindah Ke Kelas</label>
                                        <select name="kelas_id" id="kelas_id" class="form-control <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">-Pilih Kelas-</option>
                                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                    <?php if($item->id == old('kelas_id')): ?>
                                                        selected
                                                    <?php endif; ?>    
                                                >
                                                
                                                <?php echo e($item->nama_kelas); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-primary btn-block mb-3">Simpan</button>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        </form>
                        <?php else: ?> 
                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <img class="w-75" style="opacity: 0.3" src="<?php echo e(asset('/img/undraw_true_friends_c94g.png')); ?>" alt="">
                            </div>
                        </div>
                        <?php endif; ?>
                    </div> 
                </div>
                <!-- /.card -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</section>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Hapus Data Kelas</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mt-3">Apakah kamu yakin menghapus Data Kelas ?</p>
            </div>
            <div class="modal-footer">
                <form action="" method="POST" id="deleteForm">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak, Kembali</button>
                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm')
        form.action = `./kelas/${id}`
        console.log(form)
        $('#deleteModal').modal('show')
    }
    $(document).ready(function () {
        $("#one").click(function () {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });

        $("#kelas_id").change(function(){
            filter();
        });
        // $("#keyword").keypress(function(event){
        //     if(event.keyCode == 13){ // 13 adalah kode enter
        //         filter();
        //     }
        // });
        var filter = function(){
            var kelas_id = $("#kelas_id").val();
            // var keyword = $("#keyword").val();
            window.location.replace(`./kenaikanKelas?kelas_id=${kelas_id}`);
        }
    });

</script>

<?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script>
        $(document).ready(function () {
            // toastr["info"]('<?php echo e(session()->get('error')); ?>')
            iziToast.info({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\game\xampp\htdocs\si-spp2\resources\views/admin/kenaikan_kelas/index.blade.php ENDPATH**/ ?>