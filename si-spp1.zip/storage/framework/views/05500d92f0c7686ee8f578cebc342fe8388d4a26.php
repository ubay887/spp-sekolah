<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel='icon' href='<?php echo e(public_path('/storage/').\Setting::getSetting()->favicon); ?>' type='image/x-icon' />
    
    <title>Laporan Tagihan</title>
    <style>
        body{
            padding: 0;
            margin: 0;
        }
        .page{
            max-width: 80em;
            /* margin: 0 auto;' */
            /* position: absolute; */
            /* top: 170px; */
            position: relative;
            top: 15;
        }
         table th,
        table td{
            text-align: left;
        }
        
        table.layout{
            width: 100%;
            border-collapse: collapse;
        }
        
        table.display{
            margin: 1em 0;
        }
        table.display th,
        table.display td{
            border: 1px solid #B3BFAA;
            padding: .5em 1em;
        }

        table.display th{ background: #D5E0CC; }
        table.display td{ background: #fff; }
        
        /* table.responsive-table{
            box-shadow: 0 1px 10px rgba(0, 0, 0, 0.2);
        }  */

        .customer {
            padding-left: 600px;
        }

        .logo{
            position: absolute;
            left: 150px;
            top: 20px;
            z-index: 999;
        }

        .koplaporan{
            position: relative;
            height: 120px;
        }

        .logo img{
            width: 120px;
            height: 120px;
            /* position: absolute; */
            
        }

        .judul{
            position: absolute;
            top: 0;
            text-align: center;
        }

        .garis{
            margin-top: 160px;
            height: 3px;
            border-top: 3px solid black;
            border-bottom: 1px solid black;
        }

        .info{
            position: relative;
            top: 45px;
            font-size: 20px;
            text-align: center;
            padding-top: 20px;
            padding-bottom: 20px;
        }
        /* .header{
            position: relative;
            top: 0px;
            font-size: 20px;
            text-align: right;
        } */
        .sub-header{
            font-size: 20px;
        }
        
    </style>
</head>
<body>
    <div class="header">
        <div class="koplaporan">
            <div class="logo">
                <img src="<?php echo e(public_path('/img/').\Setting::getSetting()->logo); ?>" alt="">
            </div>
            <div class="judul">
                <p>
                    <?php echo e($sekolahInfo->nama_sekolah); ?><br>
                    <span class="sub-header"><?php echo e($sekolahInfo->alamat); ?></span><br>
                    <span class="sub-header"><?php echo e($sekolahInfo->kota); ?></span><br>
                    <span class="sub-header">Telp. <?php echo e($sekolahInfo->no_telp); ?></span><br>

                </p>
            </div>
            <div class="garis"></div>
        </div>
        
        
        
        
        
    </div>
    
    <div class="info">
        
        <strong>Laporan Tagihan </strong> <br>
        <table style="margin-left: auto; margin-right: auto;">
            <tr>
                <td style="vertical-align: text-top">Jenis Pembayaran</td>
                <td style="padding-left: 10px; padding-right: 10px; vertical-align: text-top">:</td>
                <td ><?php echo e($data->first()->jenis_pembayaran->nama_pembayaran); ?></td>
            </tr>
            <tr>
                <td>Tahun Pelajaran</td>
                <td style="padding-left: 10px; padding-right: 10px ">:</td>
                <td><?php echo e($data->first()->jenis_pembayaran->tahunajaran->tahun_ajaran); ?></td>
            </tr>
            <tr>
                <td>Nominal</td>
                <td style="padding-left: 10px; padding-right: 10px ">:</td>
                <td>Rp. <?php echo e(number_format($data->first()->jenis_pembayaran->harga)); ?></td>
            </tr>
            <tr>
                <td>Tipe</td>
                <td style="padding-left: 10px; padding-right: 10px ">:</td>
                <td><?php echo e(($jenisPembayaranTipe === "bulanan") ? 'Bulanan' : 'Angsuran/Bebas'); ?></td>
            </tr>
            <tr>
                <td>Dicetak Tanggal</td>
                <td style="padding-left: 10px; padding-right: 10px ">:</td>
                <td><?php echo e(date("d-m-Y")); ?></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td style="padding-left: 10px; padding-right: 10px ">:</td>
                <td><?php echo e(($namaKelas == "") ? 'Semua Kelas' : $namaKelas); ?></td>
            </tr>
        </table>
        <table>
            <tr>
                <td>Keterangan :</td>
            </tr>
            <tr>
                <td><span style="color: green">v</span> = Lunas |</td>
                <td><span style="color: red">x</span> = Belum Lunas</td>
            </tr>
        </table>
    </div>
    <div class="page">
        
            
        <table class="layout display responsive-table" style="font-size: 18px">
            <thead>
                <tr >
                    <th style="text-align: center">#</th>
                    <th style="text-align: center">NIS/Nama</th>
                    <?php if($jenisPembayaranTipe === 'bulanan'): ?>
                        <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($item); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>Total</th>
                    <?php else: ?>
                    <th>Sisa</th> 
                    <th>Total Bayar</th> 
                    <th>
                        Status
                    </th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                    $grandTotal = 0;
                    $totalBayar = 0;
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="width: 30px"><?php echo e($loop->iteration); ?></td>
                    <td>
                        <?php echo e(@$row->siswa->nis); ?> -
                        <?php echo e(@$row->siswa->kelas->nama_kelas); ?> <br>
                        <?php echo e(@$row->siswa->nama_lengkap); ?>

                    </td>
                    <?php if($jenisPembayaranTipe !== 'bulanan'): ?>
                        <td style="width: 100px; text-align:right;">
                            <?php if($row->tagihan_detail[0]->sisa != 0): ?>
                            <?php echo e(number_format($row->tagihan_detail[0]->sisa)); ?>

                                
                            <?php endif; ?>
                        </td>
                        <td style="width: 100px; text-align:right;">
                            <?php if($row->tagihan_detail[0]->total_bayar != 0): ?>

                            
                                <?php echo e(number_format($row->tagihan_detail[0]->total_bayar)); ?>

                                <?php
                                    $totalBayar = $totalBayar + $row->tagihan_detail[0]->total_bayar
                                ?>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                    <?php
                        $total = 0;
                    ?>
                    <?php $__currentLoopData = $row->tagihan_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="width: 30px; text-align:center;">
                            <?php if($item->status === 'Lunas'): ?>
                            <span style="color: green">v</span>
                                <?php
                                    $total = $total + $data->first()->jenis_pembayaran->harga;
                                ?>
                            
                            <?php endif; ?>
                            <?php if($item->status === 'Belum Lunas'): ?>
                            <span style="color: red">x</span>
                                
                            <?php endif; ?>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $grandTotal = $grandTotal + $total;
                    ?>
                    <?php if($jenisPembayaranTipe === 'bulanan'): ?>
                    <td style="width: 30px;text-align:right;"><?php echo e(number_format($total)); ?></td>
                        
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php if($jenisPembayaranTipe === 'bulanan'): ?>
                <tr>
                    <td colspan="12"style="text-align:right;"></td>
                    <td colspan="2" style="text-align:right;">Total</td>
                    <td style="text-align:right;"><?php echo e(number_format($grandTotal)); ?></td>
                </tr>
                <?php else: ?> 
                <tr>
                    
                    <td colspan="3" style="text-align:right;">Total</td>
                    <td style="text-align:right;"><?php echo e(number_format($totalBayar)); ?></td>
                    <td></td>
                </tr>
                <?php endif; ?>
            
            </tbody>
        </table>
        
            
            <table border="0" style="width: 100%; font-size: 20px">
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td style="text-align: center"><?php echo e($sekolahInfo->kota); ?>, <?php echo e(date("d-m-Y")); ?></td>
                </tr>
                <tr >
                    <td></td>
                    <td style="text-align: center">Kepala Sekolah</td>
                    <td></td>
                    <td style="text-align: center">Bendahara</td>
                </tr>
                <tr>
                    <td style="width: 100px"></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td></td>
                    <td style="text-align: center">_________________</td>
                    <td style="height: 200px"></td>
                    <td style="text-align: center">_________________</td>
                </tr>
            </table>

        
        

        

        
    
    </div>
</body>
</html><?php /**PATH C:\game\xampp\htdocs\si-spp2\resources\views/admin/laporan/cetakTagihanPdf.blade.php ENDPATH**/ ?>