<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Manajemen Laporan</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Laporan Tagihan</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <h4>Laporan Tagihan Siswa/i</h4>
                        <div class="card-header-action">
                            
                            
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form action="<?php echo e(route('laporan.tagihan')); ?>" method="GET">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kelas_id">Kelas</label>
                                    <select name="kelas_id" id="kelas_id" class="form-control <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">-Semua Kelas-</option>
                                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                                <?php if($item->id == request()->kelas_id): ?>
                                                    selected
                                                <?php endif; ?>    
                                            >
                                            
                                            <?php echo e($item->nama_kelas); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                
                                <div class="form-group">
                                    <label for="jenisPembayaran">Jenis Pembayaran</label>
                                    <select class="form-control" name="jenisPembayaran" id="jenisPembayaran" required>
                                        <option value="">Pilih</option>
                                        <?php $__currentLoopData = $jenisPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e((request()->jenisPembayaran == $item->id) ? 'selected' : ''); ?>><?php echo e($item->nama_pembayaran); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['jenisPembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-info float-right">Tampilkan</button>
                                </div>
                            </div>
                        </div>
                        </form>
                        <hr>
                        <?php if(!empty($jenisPembayaranTipe) && $tagihan->count() != 0): ?>
                            <div class="div">
                                <a href="<?php echo e(route('laporan.tagihanPdf')); ?>" target="blank" class="btn btn-light">
                                    <i class="fas fa-file-pdf    "></i>
                                    PDF
                                </a>
                                <a href="<?php echo e(route('laporan.tagihanExcel')); ?>" target="blank" class="btn btn-light">
                                    <i class="fas fa-file-excel    "></i>
                                    Excel
                                </a>
                            </div>
                            <div class="mt-3">
                                <strong>Jenis Pembayaran : <?php echo e($tagihan->first()->jenis_pembayaran->nama_pembayaran); ?></strong> <br>
                                <strong>Nominal : Rp. <?php echo e(number_format($tagihan->first()->jenis_pembayaran->harga)); ?></strong> <br>
                                <strong>Tipe : <?php echo e(($jenisPembayaranTipe === "bulanan") ? 'Bulanan' : 'Angsuran/Bebas'); ?></strong><br>
                                <strong><?php echo e((request()->session()->get('nama_kelas') == "") ? "Semua Kelas" : request()->session()->get('nama_kelas')); ?></strong> <br>
                                
                                
                                
                            </div>
                            
                                <div class="table-responsive small  ">
                                    
                                    <table class="table table-head-fixed text-nowrap table-bordered table-striped mt-3">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nis Nama</th>
                                                <?php if($jenisPembayaranTipe === 'bulanan'): ?>
                                                    <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th><?php echo e($item); ?></th>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <th class="text-center">Total Bayar</th> 
                                                <th class="text-center">Sisa</th> 
                                                <th>
                                                    Status
                                                </th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td>
                                                        <?php echo e(@$row->siswa->nis); ?> -
                                                        <?php echo e(@$row->siswa->kelas->nama_kelas); ?> <br>
                                                        <?php echo e(@$row->siswa->nama_lengkap); ?>

                                                    </td>
                                                    <?php if($jenisPembayaranTipe !== 'bulanan'): ?>
                                                        <td class="text-right"><?php echo e(number_format($row->tagihan_detail[0]->total_bayar)); ?></td>
                                                        <td class="text-right">
                                                            <?php if($row->tagihan_detail[0]->sisa == 0): ?>
                                                                -
                                                            <?php else: ?> 
                                                                <?php echo e(number_format($row->tagihan_detail[0]->sisa)); ?>


                                                            <?php endif; ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    
                                                    
                                                    <?php $__currentLoopData = $row->tagihan_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td style="width: 30px" class="text-center">
                                                            <?php if($item->status === 'Lunas'): ?>
                                                            <i class="fas fa-check-circle text-success   " title="<?php echo e($item->status); ?>"></i>
                                                            <?php endif; ?>
                                                            <?php if($item->status === 'Belum Lunas'): ?>
                                                                <i class="fas fa-times-circle text-danger   "></i>
                                                            <?php endif; ?>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
                                        </tbody>
                                    </table>
                                    
                                </div>
                            
                        <?php else: ?> 
                        <div class="text-center mt-4">
                            <?php if(request()->jenisPembayaran): ?>
                                <strong>Data Tidak Ditemukan!!</strong>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>    
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm')
        form.action = `./kelas/${id}`
        console.log(form)
        $('#deleteModal').modal('show')
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\game\xampp\htdocs\si-spp2\resources\views/admin/laporan/laporanTagihan.blade.php ENDPATH**/ ?>