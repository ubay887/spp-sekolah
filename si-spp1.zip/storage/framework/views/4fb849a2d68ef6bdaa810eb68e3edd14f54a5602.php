<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Settings</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Settings</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <a href="<?php echo e(route('setting.index')); ?>" class="btn">
                            <i class="fas fa-arrow-left  text-dark  "></i>
                        </a>
                        <h4>Pengaturan Payment Gateway Midtrans</h4>
                        <div class="card-header-action">
                            
                            
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <form method="POST"
                                    action="<?php echo e(route('setting.updatePayment', 1)); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="client_key_sandbox">Client Key Sandbox</label>
                                                <a class="" href="#" onclick="handleModal ()">
                                                    <i class="fas fa-question-circle    "></i>
                                                </a>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['client_key_sandbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="client_key_sandbox" id="client_key_sandbox"
                                                    value="<?php echo e((!empty($setting->client_key_sandbox)) ? $setting->client_key_sandbox : ''); ?>"
                                                    placeholder="Masukkan Nama kategori" autofocus>
                                                <?php $__errorArgs = ['client_key_sandbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="server_key_sandbox">Server Key Sandbox</label>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['server_key_sandbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="server_key_sandbox" id="server_key_sandbox"
                                                    value="<?php echo e((!empty($setting->server_key_sandbox)) ? $setting->server_key_sandbox : ''); ?>"
                                                    placeholder="Masukkan Nama kategori" autofocus>
                                                <?php $__errorArgs = ['server_key_sandbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="environment">Environment</label>
                                                <select class="form-control" name="environment" id="environment">
                                                    <option value="sandbox"
                                                        <?php echo e((!empty($setting->environment) === "sandbox") ? 'selected' : ''); ?>>
                                                        Sandbox</option>
                                                    <option value="production"
                                                        <?php echo e((!empty($setting->environment) === "production") ? 'selected' : ''); ?>>
                                                        Production</option>
                                                </select>
                                                <small id="emailHelp" class="form-text text-muted">Untuk tes/ujicoba
                                                    aplikasi, gunakan environment Sandbox. </small>
                                            </div>
                                        </div>
                                        <!-- /.col-md -->
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="client_key_production" class="text-danger">Client Key
                                                    Production</label>
                                                    <a class="" href="#" onclick="handleModalProd ()">
                                                        <i class="fas fa-question-circle    "></i>
                                                    </a>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['client_key_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="client_key_production" id="client_key_production"
                                                    value="<?php echo e((!empty($setting->client_key_production)) ? $setting->client_key_production : ''); ?>"
                                                    placeholder="Masukkan Nama kategori" autofocus>
                                                <?php $__errorArgs = ['client_key_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="server_key_production" class="text-danger">Server Key Production</label>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['server_key_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="server_key_production" id="server_key_production"
                                                    value="<?php echo e((!empty($setting->server_key_production)) ? $setting->server_key_production : ''); ?>"
                                                    placeholder="Masukkan Nama kategori" autofocus>
                                                <?php $__errorArgs = ['server_key_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            

                                    </div>
                                    <!-- /.col-md -->
                            </div>
                            <!-- /.row -->




                            <hr>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary float-right">
                                    Submit
                                </button>
                            </div>
                            </form>
                        </div>

                    </div>
                </div>
                <!-- /.card-body -->
                
            </div>
            <!-- /.card -->
        </div>
        </div>

    </section>
    <!-- /.content -->
    
</section>

<div class="modal fade" tabindex="-1" role="dialog" id="modalSandbox" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cara Mendapatkan Client Dan Server Key Sandbox Environment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span
                        aria-hidden="true">×</span> </button>
            </div>
            <div class="modal-body"> 
                <ol>
                    <li>Buka Dashboard Midtrans.</li>
                    <li>Ubah Pilihan Environment di pojok kiri atas pada halaman dashboard Midtrans menjadi <strong>Sandbox</strong>.</li>
                    <li>Kemudian Pilih Menu <strong>Settings > Access Keys</strong>.</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="modalProd" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cara Mendapatkan Client Dan Server Key Production Environment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span
                        aria-hidden="true">×</span> </button>
            </div>
            <div class="modal-body"> 
                <ol>
                    <li>Buka Dashboard Midtrans.</li>
                    <li>Ubah Pilihan Environment di pojok kiri atas pada halaman dashboard Midtrans menjadi <strong>Production</strong>.</li>
                    <li>Kemudian Pilih Menu <strong>Settings > Access Keys</strong>.</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleModal() {
        $('#modalSandbox').modal('show')
    }
    function handleModalProd() {
        $('#modalProd').modal('show')
    }
</script>
<script>
    $(document).ready(function () {
        $('.dropify').dropify();
        $('.logo').dropify();
        $('.favicon').dropify();
    });

</script>
<?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samikun\Videos\fortesting\lara7-spp-master\si-spp\resources\views/setting/settingPayment.blade.php ENDPATH**/ ?>