<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Siswa</title>
    
</head>
<body>
    <div class="header" style="text-align: center;">
        <h4 ><?php echo e($sekolahInfo->nama_sekolah); ?></h4>
        <p><?php echo e($sekolahInfo->alamat); ?></p>
        <p><?php echo e($sekolahInfo->kota); ?></p>
        <p>No. Telpon : <?php echo e($sekolahInfo->no_telp); ?></p>
        
    </div>
    
        
        <p></p>       
        <p><strong>Laporan Data Siswa/i</strong></p>       
        <p></p>       
    <div class="page">
        <table>
            <thead>
                <tr>
                    <th style="text-align:center; border: 1px solid black">NO</th>
                    <th style="text-align:center; border: 1px solid black">Nis</th>
                    <th style="text-align:center; border: 1px solid black">Nama</th>
                    <th style="text-align:center; border: 1px solid black">Tgl.Lahir</th>
                    <th style="text-align:center; border: 1px solid black">JK</th>
                    <th style="text-align:center; border: 1px solid black">Kelas</th>
                    <th style="text-align:center; border: 1px solid black">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr >
                    <td style="text-align:center; border: 1px solid black"><?php echo e($loop->iteration); ?></td>
                    <td style="text-align:center; border: 1px solid black"><?php echo e($row->nis); ?></td>
                    <td style="text-align:left; border: 1px solid black"><?php echo e($row->nama_lengkap); ?></td>
                    <td style="text-align:center; border: 1px solid black"><?php echo e(date_format(date_create($row->tanggal_lahir),"d-m-Y")); ?></td>
                    <td style="text-align:center; border: 1px solid black">
                        <?php echo e($row->jk); ?>   
                    </td>
                    <td style="text-align:center; border: 1px solid black">
                        <?php echo e($row->kelas->nama_kelas); ?>   
                    </td>
                    <td style="text-align:center; border: 1px solid black">
                        <?php echo e($row->status); ?>   
                    </td>
                     
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">Tidak ada data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH C:\game\php8\htdocs\si-spp2\resources\views/admin/siswa/cetak/excel.blade.php ENDPATH**/ ?>