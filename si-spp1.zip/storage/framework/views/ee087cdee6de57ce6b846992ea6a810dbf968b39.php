<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header">
        <h1>Manajemen Siswa</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('siswa.index')); ?>">Siswa</a></div>
            <div class="breadcrumb-item">Profile Siswa</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">

        <div class="row">
            <div class="col-12">
                <div class="card author-box">
                    <div class="card-header  iseng-sticky bg-white">
                        <a href="<?php echo e(route('siswa.index')); ?>" class="btn">
                            <i class="fas fa-arrow-left  text-dark  "></i>
                        </a>
                        <h4 class="ml-3">Profile Siswa</h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(route('siswa.edit', $data->id)); ?>" class="btn btn-primary btn-icon"
                                data-toggle="tooltip" data-placement="top" title=""
                                data-original-title="Edit">
                                <i class="fas fa-user-edit    "></i>
                            </a>
                            
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="author-box-left">
                            <img width="100" height="100" alt="image" src="<?php echo e(asset('/img/siswa/'.$data->foto)); ?>"
                                class="rounded-circle author-box-picture">
                            <div class="clearfix"></div>
                            <div class="user-details mt-3">
                                <div class="user-name"><?php echo e($data->nama_lengkap); ?></div>
                                <div class="text-job text-muted"><?php echo e($data->nis); ?></div>
                                <div class="user-cta mt-3">
                                  <span class="badge badge-success"><?php echo e($data->status); ?></span>
                                </div>
                              </div>
                        </div>
                        <div class="author-box-details">
                            <div class="author-box-description">

                                <ul class="nav nav-tabs" id="myTab2" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active show" id="home-tab2" data-toggle="tab" href="#home2"
                                            role="tab" aria-controls="home" aria-selected="true">Profile</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="profile-tab2" data-toggle="tab" href="#profile2"
                                            role="tab" aria-controls="profile" aria-selected="false">Tagihan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="profile-tab2" data-toggle="tab" href="#pembayaran"
                                            role="tab" aria-controls="profile" aria-selected="false">Riwayat Pembayaran</a>
                                    </li>
                                    
                                </ul>
                                <div class="tab-content tab-bordered" id="myTab3Content">
                                    <div class="tab-pane fade active show" id="home2" role="tabpanel"
                                        aria-labelledby="home-tab2">
                                        <div class="row">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-5 py-3">
                                                <h6> <u>Data Pribadi</u> </h6>
                                                <strong>Nomor Induk Siswa</strong><br>
                                                <?php echo e($data->nis); ?>

                                                <br><br>
                                                <strong>Nama Lengkap</strong><br>
                                                <?php echo e($data->nama_lengkap); ?>

                                                <br><br>
                                                <strong>Jenis Kelamin</strong><br>
                                                <?php echo e(($data->nis === 'male') ? 'Laki-Laki' : 'Perempuan'); ?>

                                                <br><br>
                                                <strong>Tempat Lahir</strong><br>
                                                <?php echo e($data->tempat_lahir); ?>

                                                <br><br>
                                                <strong>Tanggal Lahir</strong><br>
                                                <?php echo e($data->tanggal_lahir); ?>

                                                <br><br>
                                                <strong>Kelas</strong><br>
                                                <?php echo e($data->kelas->nama_kelas); ?>

                                                <br><br>
                                                <strong>No. HP</strong><br>
                                                <?php echo e($data->no_telp); ?>

                                            </div>
                                            <!-- /.col-md -->
                                            <div class="col-md-6 py-3 px-3">
                                                <h6> <u>Data Orangtua</u> </h6>
                                                <strong>Nama Ibu Kandung</strong><br>
                                                <?php echo e($data->nama_ibu_kandung); ?>

                                                <br><br>
                                                <strong>Nama Ayah Kandung</strong><br>
                                                <?php echo e($data->nama_ayah_kandung); ?>

                                                <br><br>
                                                <strong>No. Telp Orangtua</strong><br>
                                                <?php echo e($data->no_telp_orangtua); ?>

                                                <br><br>
                                                <strong>Alamat</strong><br>
                                                <?php echo e($data->alamat); ?>

                                            </div>
                                            <!-- /.col-md -->
                                        </div>
                                        
                                        
                                    </div>
                                    <div class="tab-pane fade" id="profile2" role="tabpanel"
                                        aria-labelledby="profile-tab2">
                                        <div id="accordion">
                                            
                                            <?php if($data->tagihan->count()): ?>
                                                <div class="mb-3">
                                                    <button data-toggle="modal" data-target="#tagihanModal" class="btn btn-primary btn-sm">Tambah Tagihan</button>
                                                </div>   
                                            <?php endif; ?>
                                            
                                            <?php $__empty_1 = true; $__currentLoopData = $data->tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="accordion">
                                                <div class="accordion-header collapsed" role="button" data-toggle="collapse" data-target="#panel-body-<?php echo e($row->id); ?>" aria-expanded="false">
                                                    <div class="d-flex justify-content-between">
                                                        <h4><?php echo e($row->jenis_pembayaran->nama_pembayaran); ?></h4>
                                                        
                                                        <h4><?php echo e($row->jenis_pembayaran->tahunajaran->tahun_ajaran); ?></h4>
                                                    </div>
                                                    
                                                </div>
                                                <div class="accordion-body collapse" id="panel-body-<?php echo e($row->id); ?>" data-parent="#accordion" style="">
                                                    <div class="table-responsive">
                                                        <?php if($row->jenis_pembayaran->tipe === "bulanan"): ?>
                                                            <table class="table table-hover">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Nominal</th>
                                                                        <th>Keterangan</th>
                                                                        <th>Status</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $row->tagihan_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td>Rp.<?php echo e(number_format($row->jenis_pembayaran->harga)); ?></td>
                                                                        <td><?php echo e($item->keterangan); ?></td>
                                                                        <td>
                                                                            <?php if($item->status === "Lunas"): ?>
                                                                                <i class="fas fa-check-circle  text-success mr-2 "></i>
                                                                            <?php else: ?> 
                                                                                <i class="fas fa-times-circle text-info  mr-2 "></i>    
                                                                            <?php endif; ?>
                                                                            <?php echo e($item->status); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        <?php else: ?>    
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th>Nominal</th>
                                                                    <th>Total Bayar</th>
                                                                    <th>Sisa</th>
                                                                    <th>Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $row->tagihan_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td>Rp.<?php echo e(number_format($row->jenis_pembayaran->harga)); ?></td>
                                                                    <td>Rp.<?php echo e(number_format($item->total_bayar)); ?></td>
                                                                    <td>Rp.<?php echo e(number_format($item->sisa)); ?></td>
                                                                    <td>
                                                                        <?php if($item->status === "Lunas"): ?>
                                                                                <i class="fas fa-check-circle  text-success mr-2  "></i>
                                                                            <?php else: ?> 
                                                                                <i class="fas fa-times-circle text-info mr-2  "></i>    
                                                                            <?php endif; ?>
                                                                        <?php echo e($item->status); ?>

                                                                    </td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                        <?php endif; ?>
                                                    </div>
                                                    <!-- /.table-responsive -->
                                                    <button onclick="handleDelete (<?php echo e($row->id); ?>)" class="btn btn-sm btn-danger float-right mb-3"><i class="fas fa-trash    "></i></button>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p class="text-center mt-4">Belum Ada Tagihan</p>
                                            <div class="text-center mb-4">
                                                <button data-toggle="modal" data-target="#tagihanModal" class="btn btn-primary">Buat Tagihan Baru</button>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="pembayaran" role="tabpanel"
                                        aria-labelledby="profile-tab2">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr class="text-center">
                                                        <th>Tanggal Pembayaran</th>
                                                        <th>Nama Pembayaran</th>
                                                        <th>Keterangan</th>
                                                        <th>Jumlah Bayar</th>
                                                        <th>Metode Pembayaran</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            
                                                            <?php echo e($item->created_at); ?>

                                                        </td>
                                                        <td><?php echo e($item->nama_pembayaran); ?></td>
                                                        <td><?php echo e($item->keterangan); ?></td>
                                                        <td class="text-right">Rp.<?php echo e(number_format($item->harga)); ?></td>
                                                        <td class="text-center"><?php echo e($item->transaksi_pembayaran->metode_pembayaran); ?></td>
                                                    </tr>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                    
                </div>
                <!-- /.card -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</section>
<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Hapus Data Tagihan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mt-3">Apakah kamu yakin menghapus Tagihan ?</p>
            </div>
            <div class="modal-footer">
                <form action="" method="POST" id="deleteForm">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak, Kembali</button>
                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tagihan-->
<div class="modal fade" id="tagihanModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Buat Tagihan Untuk <?php echo e($data->nama_lengkap); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('siswa.createTagihan')); ?>" method="POST" id="deleteForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="siswaId" value="<?php echo e($data->id); ?>">
                <?php
                    $totalCheck = 0;
                ?>
                <?php $__currentLoopData = $jenisPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php
                        $s = false;
                    ?>

                    <?php $__currentLoopData = $data->tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id == $cek->jenis_pembayaran_id): ?>
                            <?php
                                $s = true;
                                $totalCheck++;
                            ?>
                        <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="custom-control custom-checkbox py-1">
                            <input type="checkbox" class="custom-control-input" name="jenisPembayaran_id[]" id="item<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" <?php echo e(($s) ? 'checked disabled' : ''); ?> >
                            <label class="custom-control-label d-flex justify-content-between <?php echo e(($s) ? 'text-muted' : ''); ?>" for="item<?php echo e($item->id); ?>">
                                <span>
                                    <strong><?php echo e($item->nama_pembayaran); ?></strong> 
                                    <span class="text-right">
                                        <?php if($item->tipe === "bulanan"): ?>
                                            <span class="">(Setiap Bulan)</span>
                                        <?php else: ?> 
                                            <span class="">(Angsuran/Bebas)</span>
                                        <?php endif; ?>
                                    </span>
                                    <br>
                                <span class="small">TP.<?php echo e($item->tahunajaran->tahun_ajaran); ?></span>
                                </span>
                                <span><?php echo e(number_format($item->harga)); ?></span>
                            </label>
                        </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="modal-footer">
                
                    
                    
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary" <?php echo e(($jenisPembayaran->count() == $totalCheck) ? 'disabled' : ''); ?>>Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#kelas_id').select2()

        $('#foto_siswa').dropify({
            messages: {
                'default': '',
                'replace': 'Drag and drop or click to replace',
                'remove': 'Remove',
                'error': 'Ooops, something wrong happended.'
            }
        });

    });

</script>

<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm')
        form.action = `../siswa/deleteTagihan/${id}`
        console.log(form)
        $('#deleteModal').modal('show')
    }

</script>

<?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script>
        $(document).ready(function () {
            // toastr["info"]('<?php echo e(session()->get('error')); ?>')
            iziToast.info({
                title: '',
                message: '<?php echo e(session()->get('error')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samikun\Videos\fortesting\New folder\si-spp\resources\views/admin/siswa/show.blade.php ENDPATH**/ ?>