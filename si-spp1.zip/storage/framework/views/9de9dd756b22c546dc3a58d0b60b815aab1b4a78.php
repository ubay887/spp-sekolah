<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Manajemen Pembayaran</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Detail Pembayaran</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <a href="<?php echo e(route('pembayaran.index')); ?>" class="btn">
                            <i class="fas fa-arrow-left  text-dark  "></i>
                        </a>
                        <h4 class="ml-3">Detail Pembayaran</h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(route('pembayaran.cetak', $detail->id)); ?>" target="blank" class="btn btn-secondary btn-icon"
                                data-toggle="tooltip" data-placement="top" title=""
                                data-original-title="Print">
                                <i class="fas fa-print    "></i>
                            </a>
                            
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <div class="text-left">
                                    <strong>Status</strong><br>
                                    <?php if($detail->status === "cancel"): ?>
                                        <span class="text-secondary">
                                            <i class="fas fa-info-circle    "></i>
                                            Cancel
                                        </span>
                                        <br>
                                        <br>
                                        <span>
                                            Cancel at : <br>
                                            <?php echo e($detail->updated_at); ?>

                                        </span>
                                    <?php endif; ?>
                                    <?php if($detail->status === "expire"): ?>
                                        <span class="text-danger">
                                            <i class="fas fa-times-circle    "></i>
                                            Expire
                                        </span>
                                        <br>
                                        <br>
                                        <span>
                                            Expire at : <br>
                                            <?php echo e($detail->updated_at); ?>

                                        </span>
                                    <?php endif; ?>
                                    <?php if($detail->status === "settlement" || $detail->status === "Success"): ?>
                                        <span class="text-success">
                                            <i class="fas fa-check-circle    "></i>
                                            Paid
                                        </span>
                                        <br>
                                        <br>
                                        <span>
                                            Settlement at : <br>
                                            <?php echo e($detail->updated_at); ?>

                                        </span>
                                        <br>
                                        <br>
                                        <span>
                                            <?php if($detail->metode_pembayaran === "Loket"): ?>
                                            <strong>Penerima :</strong> <br>
                                            <?php echo e($detail->user->name); ?>

                                                
                                            <?php endif; ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if($detail->status === "pending"): ?>
                                        <span class="text-warning">
                                            <i class="fas fa-info-circle    "></i>
                                            Pending
                                        </span>
                                        <br>
                                        <br>
                                        <span>
                                            Segera Lakukan Pembayaran Sebelum : <br>
                                            <?php echo e($detail->due_date); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6 mx-auto ">
                                
                                <div class="d-flex justify-content-between">
                                    <address>
                                        <strong>Data Siswa/i:</strong><br>
                                        <?php echo e($detail->siswa->nis); ?><br>
                                        <?php echo e($detail->siswa->nama_lengkap); ?><br>
                                        <?php echo e($detail->siswa->kelas->nama_kelas); ?><br>
                                    </address>
                                    <address class="text-right">
                                        <strong>Tanggal Pembayaran:</strong><br>
                                        <?php echo e($detail->created_at); ?><br>
                                        <strong>Metode Pembayaran:</strong><br>
                                        <?php echo e($detail->metode_pembayaran); ?><br>
                                        <?php echo e($detail->pembayaran_detail); ?><br>
                                    </address>
                                </div>

                                <div class="section-title">Detail Pembayaran</div>
                                <div>
                                    <?php $__currentLoopData = $detail->detail_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <div>
                                                <span><strong><?php echo e($item->nama_pembayaran); ?></strong></span><br>
                                                <span class="small"><?php echo e($item->keterangan); ?></span>
                                            </div>
                                            <div>
                                                <span>Rp.<?php echo e(number_format($item->harga)); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mt-4 text-right">
                                        <span class="">Total</span>
                                        <h5>Rp.<?php echo e(number_format($detail->total)); ?></h5>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">

                    </div>
                </div>
                <!-- /.card -->
                

            </div>
        </div>

    </section>
    <!-- /.content -->
</section>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Hapus Data Kelas</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mt-3">Apakah kamu yakin menghapus Data Kelas ?</p>
            </div>
            <div class="modal-footer">
                <form action="" method="POST" id="deleteForm">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak, Kembali</button>
                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm')
        form.action = `./kelas/${id}`
        console.log(form)
        $('#deleteModal').modal('show')
    }

</script>

<?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script>
        $(document).ready(function () {
            // toastr["info"]('<?php echo e(session()->get('error')); ?>')
            iziToast.info({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\game\php8\htdocs\si-spp2\resources\views/admin/pembayaran/detail.blade.php ENDPATH**/ ?>