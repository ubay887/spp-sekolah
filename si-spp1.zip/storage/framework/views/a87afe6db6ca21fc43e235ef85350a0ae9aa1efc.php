<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- Content Header (Page header) -->
    <section class="section-header ">
        <h1>Manajemen Jenis Pembayaran</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('home')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item active"><a href="<?php echo e(route('jenispembayaran.index')); ?>">Jenis Pembayaran</a></div>
            <div class="breadcrumb-item">Create Jenis Pembayaran</div>
        </div>
    </section>

    <!-- Main content -->
    <section class="section-body">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header iseng-sticky bg-white">
                        <a href="<?php echo e(route('jenispembayaran.index')); ?>" class="btn">
                            <i class="fas fa-arrow-left  text-dark  "></i>
                        </a>
                        <h4 class="ml-3">Form Tambah Jenis Pembayaran</h4>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body" >
                        <form method="POST" action="<?php echo e(route('jenispembayaran.store')); ?>">
                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="nama_pembayaran">Nama Pembayaran</label>
                                        <input type="text" name="nama_pembayaran" class="form-control <?php $__errorArgs = ['nama_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="nama_pembayaran" value="<?php echo e(old('nama_pembayaran')); ?>"  placeholder="Contoh SPP, DSP, Sumbangan apalah" autofocus>
                                        <?php $__errorArgs = ['nama_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="tahunajaran_id">Tahun Pelajaran</label>
                                        <select name="tahunajaran_id" id="tahunajaran_id" class="form-control <?php $__errorArgs = ['tahunajaran_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">-Pilih Tahun Pelajaran-</option>
                                            <?php $__currentLoopData = $tahun_ajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                    <?php if($item->id == old('tahunajaran_id')): ?>
                                                        selected
                                                    <?php endif; ?>    
                                                >
                                                
                                                <?php echo e($item->tahun_ajaran); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['tahunajaran_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="tipe">Tipe Pembayaran</label>
                                        <select name="tipe" id="tipe" class="form-control <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">-Pilih Tipe Pembayaran-</option>
                                            <option value="bulanan" <?php echo e(('bulanan' === old('tipe')) ? 'selected' : ''); ?>>Setiap Bulan</option>
                                            <option value="bebas" <?php echo e(('bebas' === old('tipe')) ? 'selected' : ''); ?>>Bebas/Angsuran</option>
                                        </select>
                                        <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="harga">Biaya/Nominal</label>
                                        <input type="number" name="harga" class="form-control <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="harga" value="<?php echo e(old('harga')); ?>"  placeholder="Masukkan Biaya atau jumlah Nominal" autofocus>
                                        <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="kelas_id">Pembayaran Untuk </label>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" 
                                            name="kelas_id[]" 
                                            value="semua" 
                                            class="custom-control-input" 
                                            id="one"
                                            <?php echo e((is_array(old('kelas_id')) && in_array($item->id, old('kelas_id'))) ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="one">Semua Kelas</label>
                                        </div>
                                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" 
                                                name="kelas_id[]" 
                                                value="<?php echo e($item->id); ?>" class="custom-control-input" 
                                                id="customCheck<?php echo e($item->id); ?>" 
                                                <?php if(is_array(old('kelas_id')) && in_array($item->id, old('kelas_id'))): ?>
                                                    checked
                                                <?php endif; ?>
                                                >
                                                <label class="custom-control-label" for="customCheck<?php echo e($item->id); ?>"><?php echo e($item->nama_kelas); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                        <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group d-flex justify-content-end">
                                        <a class="btn btn-light " href="<?php echo e(route('jenispembayaran.index')); ?>">Batal</a>
                                        <button type="submit" class="btn btn-primary ml-2">
                                            Simpan
                                        </button>
                                    </div>
                                
                            </div>
                            <!-- /.col-md -->
                            
                                

                                
                                

                                
                                
                            
                            <!-- /.col-md -->
                        </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                    
                </div>
                <!-- /.card -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/jenisPembayaran.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('#tipe').select2()
        $('#tahunajaran_id').select2()
        $("#one").click(function () {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });
    });

</script>

    <?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            // toastr["success"]('<?php echo e(session()->get('success')); ?>')
            iziToast.success({
                title: '',
                message: '<?php echo e(session()->get('success')); ?>',
                position: 'bottomCenter'
            });
        });

    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samikun\Videos\fortesting\New folder\si-spp\resources\views/admin/jenis_pembayaran/create.blade.php ENDPATH**/ ?>