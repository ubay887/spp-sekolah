<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="index.html"><?php echo e(\Setting::getSetting()->app_name); ?></a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
        <a href="<?php echo e(route('home')); ?>"><figure class="avatar avatar-sm mr-2">
            <img src="<?php echo e(asset('/img/'.\Setting::getSetting()->logo)); ?>" alt="...">
          </figure></a>
    </div>
    <ul class="sidebar-menu">
        
        <li>
            <a class="nav-link <?php echo e(request()->routeIs('home') == 'home' ? 'text-primary' : ''); ?>" href="<?php echo e(route('home')); ?>"><i class="fas fa-tachometer-alt">
                </i> <span>Dashboard</span>
            </a>
        </li>
        
        
        <li class="nav-item dropdown <?php echo e((request()->segment(1) == 'kelulusan' || request()->segment(1) == 'kenaikanKelas' || request()->segment(1) == 'kelas' ||  request()->segment(1) == 'siswa'   ) ? 'active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-graduate    "></i>
                <span>Manajemen Siswa</span></a>
            <ul class="dropdown-menu" style="display: none;">
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('siswa.index') == 'siswa.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('siswa.index')); ?>">
                        Data Siswa
                    </a>
                </li>
                
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('kelas.index') == 'kelas.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('kelas.index')); ?>">
                        Kelas
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('kelulusan.index') == 'kelulusan.index' ? 'text-primary' : ''); ?>" href="<?php echo e(route('kelulusan.index')); ?>">
                        <span>Kelulusan</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('kenaikanKelas.index') == 'kenaikanKelas.index' ? 'text-primary' : ''); ?>" href="<?php echo e(route('kenaikanKelas.index')); ?>"> 
                        <span>Pindah Kelas</span>
                    </a>
                </li>
                
            </ul>
        </li>
        <li class="nav-item dropdown <?php echo e((request()->segment(1) == 'users' || request()->segment(1) == 'roles' || request()->segment(1) == 'pegawai' ) ? 'active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie    "></i>
                <span>Manajemen User</span></a>
            <ul class="dropdown-menu" style="display: none;">
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('users.index') == 'users.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('users.index')); ?>">
                        Users
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('roles.index') == 'roles.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">
                        Roles & Permissions
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('pegawai.index') == 'pegawai.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('pegawai.index')); ?>">
                        Pegawai
                    </a>
                </li>
            </ul>
        </li>

        <li class="nav-item dropdown <?php echo e((request()->segment(1) == 'pembayaran' || request()->segment(1) == 'jenispembayaran' || request()->segment(1) == 'tahunajaran') ? 'active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-file-invoice    "></i>
                <span>Pembayaran</span></a>
            <ul class="dropdown-menu" style="display: none;">
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('pembayaran.create') == 'pembayaran.create' ? 'text-info' : ''); ?>" href="<?php echo e(route('pembayaran.create')); ?>">
                        Transaksi Pembayaran
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('pembayaran.index') == 'pembayaran.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('pembayaran.index')); ?>">
                        Data Pembayaran
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('jenispembayaran.index') == 'jenispembayaran.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('jenispembayaran.index')); ?>">
                        Jenis Pembayaran
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('tahunajaran.index') == 'tahunajaran.index' ? 'text-info' : ''); ?>" href="<?php echo e(route('tahunajaran.index')); ?>">
                        Tahun Pelajaran
                    </a>
                </li>
            </ul>
        </li>

        <li class="nav-item dropdown <?php echo e((request()->segment(1) == 'laporan') ? 'active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-columns    "></i>
                <span>Laporan</span></a>
            <ul class="dropdown-menu" style="display: none;">
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('laporan.pembayaran') == 'laporan.pembayaran' ? 'text-info' : ''); ?>" href="<?php echo e(route('laporan.pembayaran')); ?>">
                        Laporan Pembayaran
                    </a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('laporan.tagihan') == 'laporan.tagihan' ? 'text-info' : ''); ?>" href="<?php echo e(route('laporan.tagihan')); ?>">
                        Laporan Tagihan
                    </a>
                </li>
            </ul>
        </li>
        
        
        <li>
            <a class="nav-link <?php echo e(request()->routeIs('setting.index') == 'setting.index' ? 'text-primary' : ''); ?>" href="<?php echo e(route('setting.index')); ?>">
                <i class="fas fa-cog    "></i> 
                <span>Settings</span>
            </a>
        </li>
        <li>
            <a class="nav-link <?php echo e(request()->routeIs('profile.show') == 'profile.show' ? 'text-primary' : ''); ?>" href="<?php echo e(route('profile.show', Auth::user()->id)); ?>">
                <i class="fas fa-user-ninja    "></i>
                 <span>Profile</span></a>
        </li>

        
    </ul>

</aside><?php /**PATH C:\game\xampp\htdocs\si-spp2\resources\views/layouts/partials/adminSideBarMenu.blade.php ENDPATH**/ ?>