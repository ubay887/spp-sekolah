<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PengaturanPayment extends Model
{
    protected $guarded = [];

    protected $table = 'pengaturan_payment';
}
